"use client";

import type { ReactNode } from "react";
import { useEffect } from "react";
import { PiAuthProvider, usePiAuth } from "@/contexts/pi-auth-context";
import { AuthLoadingScreen } from "./auth-loading-screen";
import { initializeGlobalPayment } from "@/lib/pi-payment";

function AppContent({ children }: { children: ReactNode }) {
  const { isAuthenticated, hasError } = usePiAuth();
  
  useEffect(() => {
    try {
      // Initialize global payment function
      initializeGlobalPayment();
      console.log("[v0] Global payment function initialized");
    } catch (error) {
      console.error("[v0] Failed to initialize payment:", error);
    }
  }, []);
  
  // Show error state when authentication fails
  if (hasError) {
    return <AuthLoadingScreen />;
  }
  
  // Always render children, even if still loading
  // This allows product browsing while auth initializes
  return <>{children}</>;
}

export function AppWrapper({ children }: { children: ReactNode }) {
  return (
    <PiAuthProvider>
      <AppContent>{children}</AppContent>
    </PiAuthProvider>
  );
}
