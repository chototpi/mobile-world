"use client";

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  type ReactNode,
} from "react";
import { PI_NETWORK_CONFIG } from "@/lib/system-config";
import type {
  Product,
  SDKLiteInstance,
  UserPurchaseBalance,
} from "@/lib/sdklite-types";

const COMMUNICATION_REQUEST_TYPE = '@pi:app:sdk:communication_information_request';

function isInIframe(): boolean {
  try {
    return window.self !== window.top;
  } catch (error) {
    // Cross-origin access may throw when in an iframe
    if (
      error instanceof DOMException &&
      (error.name === 'SecurityError' || error.code === DOMException.SECURITY_ERR || error.code === 18)
    ) {
      return true;
    }
    // Firefox may throw generic Permission denied errors
    if (error instanceof Error && /Permission denied/i.test(error.message)) {
      return true;
    }

    throw error;
  }
}

function parseJsonSafely(value: any): any {
  if (typeof value === 'string') {
    try {
      return JSON.parse(value);
    } catch (error) {
      return null;
    }
  }
  return typeof value === 'object' && value !== null ? value : null;
}

/**
 * Requests authentication credentials from the parent window (App Studio) via postMessage.
 * Returns null if not in iframe, timeout, or missing token (non-fatal check).
 *
 * @returns {Promise<{accessToken: string, appId: string}|null>} Resolves with credentials or null
 */
function requestParentCredentials(): Promise<{ accessToken: string; appId: string | null } | null> {
  // Early return if not in an iframe
  if (!isInIframe()) {
    return Promise.resolve(null);
  }

  const requestId = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const timeoutMs = 1500;

  return new Promise((resolve) => {
    let timeoutId: ReturnType<typeof setTimeout> | null = null;

    // Cleanup function to remove listener and clear timeout
    const cleanup = (listener: (event: MessageEvent) => void) => {
      window.removeEventListener('message', listener);
      if (timeoutId !== null) {
        clearTimeout(timeoutId);
      }
    };

    const messageListener = (event: MessageEvent) => {
      // Security: only accept messages from parent window
      if (event.source !== window.parent) {
        return;
      }

      // Validate message type and request ID match
      const data = parseJsonSafely(event.data);
      if (!data || data.type !== COMMUNICATION_REQUEST_TYPE || data.id !== requestId) {
        return;
      }

      cleanup(messageListener);

      // Extract credentials from response payload
      const payload = typeof data.payload === 'object' && data.payload !== null ? data.payload : {};
      const accessToken = typeof payload.accessToken === 'string' ? payload.accessToken : null;
      const appId = typeof payload.appId === 'string' ? payload.appId : null;

      // Return credentials or null if missing token
      resolve(accessToken ? { accessToken, appId } : null);
    };

    // Set timeout handler (resolve with null on timeout)
    timeoutId = setTimeout(() => {
      cleanup(messageListener);
      resolve(null);
    }, timeoutMs);

    // Register listener before sending request to avoid race condition
    window.addEventListener('message', messageListener);

    // Send request to parent window to get credentials
    window.parent.postMessage(
      JSON.stringify({
        type: COMMUNICATION_REQUEST_TYPE,
        id: requestId
      }),
      '*'
    );
  });
}

interface PiAuthContextType {
  isAuthenticated: boolean;
  authMessage: string;
  hasError: boolean;
  sdk: SDKLiteInstance | null;
  products: Product[] | null;
  restoredPurchases: UserPurchaseBalance[] | null;
  username: string | null;
  reinitialize: () => Promise<void>;
}

const PiAuthContext = createContext<PiAuthContextType | undefined>(undefined);

const loadPiSDK = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (typeof window.Pi !== "undefined") {
      resolve();
      return;
    }

    const script = document.createElement("script");
    if (!PI_NETWORK_CONFIG.SDK_URL) {
      reject(new Error("SDK URL is not set"));
      return;
    }
    script.src = PI_NETWORK_CONFIG.SDK_URL;
    script.async = true;

    script.onload = () => {
      console.log("Pi SDK script loaded successfully");
      resolve();
    };

    script.onerror = () => {
      console.error("Failed to load Pi SDK script");
      reject(new Error("Failed to load Pi SDK script"));
    };

    document.head.appendChild(script);
  });
};

// Currently unused while the payment flow is disabled (see initialize()).
const loadSDKLite = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (typeof window.SDKLite !== "undefined") {
      resolve();
      return;
    }

    const script = document.createElement("script");
    if (!PI_NETWORK_CONFIG.SDK_LITE_URL) {
      reject(new Error("SDKLite URL is not set"));
      return;
    }
    script.src = PI_NETWORK_CONFIG.SDK_LITE_URL;
    script.async = true;

    script.onload = () => {
      console.log("SDKLite script loaded successfully");
      resolve();
    };

    script.onerror = () => {
      console.error("Failed to load SDKLite script");
      reject(new Error("Failed to load SDKLite script"));
    };

    document.head.appendChild(script);
  });
};

export function PiAuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authMessage, setAuthMessage] = useState("Initializing Pi Network...");
  const [hasError, setHasError] = useState(false);
  const [sdk, setSdk] = useState<SDKLiteInstance | null>(null);
  const [products, setProducts] = useState<Product[] | null>(null);
  const [restoredPurchases, setRestoredPurchases] = useState<
    UserPurchaseBalance[] | null
  >(null);
  const [username, setUsername] = useState<string | null>(null);

  // Currently unused while the payment flow is disabled (see initialize()).
  // Kept so it's a one-line change to wire back in when payments return.
  const fetchProducts = async (sdkInstance: SDKLiteInstance): Promise<void> => {
    try {
      const { products } = await sdkInstance.state.products();
      setProducts(products);
    } catch (e) {
      console.error("Failed to load products:", e);
      setProducts([]);
    }
  };

  // Callback for incomplete payments
  const onIncompletePaymentFound = (payment: any) => {
    console.log("[v0] Incomplete payment found:", payment);
    // Handle incomplete payment - could redirect to payment flow or show notification
    // For now, just log it
  };

  const initialize = async () => {
    console.log("[v0] Initialize called");
    setHasError(false);
    setRestoredPurchases(null);
    try {
      // Probe for parent credentials (App Studio iframe environment).
      // When running inside App Studio's restore-preview iframe, SDKLite.login()
      // cannot complete outside the Pi CDN wrapper and would hang indefinitely.
      const parentCredentials = await requestParentCredentials();
      if (parentCredentials) {
        console.log("[v0] Parent credentials found, marking as authenticated");
        setIsAuthenticated(true);
        return;
      }

      setAuthMessage("Loading Pi SDK...");
      console.log("[v0] Loading Pi SDK...");
      await loadPiSDK();
      setAuthMessage("Initializing Pi Network...");
      console.log("[v0] Initializing Pi Network");
      await window.Pi.init({
        version: "2.0",
        sandbox: PI_NETWORK_CONFIG.SANDBOX,
      });

      setAuthMessage("Authenticating with Pi...");
      console.log("[v0] Starting Pi.authenticate()");
      
      // Use Pi.authenticate() with the "username" scope only.
      // Payment flow (SDKLite, "payments" scope, products, purchase restore)
      // is TEMPORARILY DISABLED below while converting this app to a plain
      // Pi Sign-In flow for Pi App Studio. To re-enable payments later,
      // add "payments" back here and restore the SDKLite block that used
      // to follow the backend verification step (git history has it).
      const scopes = ["username"];
      const authResponse = await window.Pi.authenticate(scopes, onIncompletePaymentFound);
      
      console.log("[v0] Authentication successful, response:", authResponse);
      
      if (!authResponse || !authResponse.user || !authResponse.accessToken) {
        throw new Error("Authentication failed - no user data");
      }

      // Do NOT trust the client-reported user yet. Send the accessToken to
      // our backend, which calls GET https://api.minepi.com/v2/me with it
      // and only responds success once Pi confirms the token is valid.
      // The session (isAuthenticated/username) is only established after
      // that server-side check passes.
      setAuthMessage("Verifying with server...");
      console.log("[v0] Verifying access token with backend");
      const verifyRes = await fetch("/api/pi-user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: authResponse.accessToken }),
      });

      if (!verifyRes.ok) {
        throw new Error("Server could not verify Pi access token");
      }

      const verifyData = await verifyRes.json();
      if (!verifyData.success || !verifyData.user?.username) {
        throw new Error("Server rejected Pi access token");
      }

      // Use the server-verified identity as the source of truth.
      const piUsername = verifyData.user.username;
      console.log("[v0] Backend verified user:", verifyData.user);
      setUsername(piUsername);
      localStorage.setItem('pi_username', piUsername);
      localStorage.setItem('uid', verifyData.user.uid);
      localStorage.setItem('accessToken', authResponse.accessToken);

      // Payment flow disabled for now: no SDKLite load/init, no product
      // fetch, no purchase restore. sdk/products/restoredPurchases stay at
      // their initial null values so pages that read them (buy-now-button,
      // checkout, etc.) fall back to empty state instead of crashing.
      console.log("[v0] Login-only flow complete (payments disabled)");
      setIsAuthenticated(true);
    } catch (err) {
      console.error("[v0] Pi authentication failed:", err);
      setHasError(true);
      setAuthMessage(
        err instanceof Error
          ? err.message
          : "Authentication failed. Please try again.",
      );
    }
  };

  useEffect(() => {
    // Try to restore username from localStorage
    const savedUsername = localStorage.getItem('pi_username');
    if (savedUsername) {
      setUsername(savedUsername);
    }
    initialize();
  }, []);

  const value: PiAuthContextType = {
    isAuthenticated,
    authMessage,
    hasError,
    sdk,
    products,
    restoredPurchases,
    username,
    reinitialize: initialize,
  };

  return (
    <PiAuthContext.Provider value={value}>{children}</PiAuthContext.Provider>
  );
}

export function usePiAuth() {
  const context = useContext(PiAuthContext);
  if (context === undefined) {
    throw new Error("usePiAuth must be used within a PiAuthProvider");
  }
  return context;
}
