"use client";

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  type ReactNode,
} from "react";
import { PI_NETWORK_CONFIG } from "@/lib/system-config";
import type {
  Product,
  SDKLiteInstance,
  UserPurchaseBalance,
} from "@/lib/sdklite-types";

interface PiAuthContextType {
  isAuthenticated: boolean;
  authMessage: string;
  hasError: boolean;
  sdk: SDKLiteInstance | null;
  products: Product[] | null;
  restoredPurchases: UserPurchaseBalance[] | null;
  username: string | null;
  reinitialize: () => Promise<void>;
}

const PiAuthContext = createContext<PiAuthContextType | undefined>(undefined);

const loadPiSDK = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (typeof window.Pi !== "undefined") {
      resolve();
      return;
    }

    const script = document.createElement("script");
    if (!PI_NETWORK_CONFIG.SDK_URL) {
      reject(new Error("SDK URL is not set"));
      return;
    }
    script.src = PI_NETWORK_CONFIG.SDK_URL;
    script.async = true;

    script.onload = () => {
      console.log("Pi SDK script loaded successfully");
      resolve();
    };

    script.onerror = () => {
      console.error("Failed to load Pi SDK script");
      reject(new Error("Failed to load Pi SDK script"));
    };

    document.head.appendChild(script);
  });
};

// Currently unused while the payment flow is disabled (see initialize()).
const loadSDKLite = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (typeof window.SDKLite !== "undefined") {
      resolve();
      return;
    }

    const script = document.createElement("script");
    if (!PI_NETWORK_CONFIG.SDK_LITE_URL) {
      reject(new Error("SDKLite URL is not set"));
      return;
    }
    script.src = PI_NETWORK_CONFIG.SDK_LITE_URL;
    script.async = true;

    script.onload = () => {
      console.log("SDKLite script loaded successfully");
      resolve();
    };

    script.onerror = () => {
      console.error("Failed to load SDKLite script");
      reject(new Error("Failed to load SDKLite script"));
    };

    document.head.appendChild(script);
  });
};

export function PiAuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authMessage, setAuthMessage] = useState("Initializing Pi Network...");
  const [hasError, setHasError] = useState(false);
  const [sdk, setSdk] = useState<SDKLiteInstance | null>(null);
  const [products, setProducts] = useState<Product[] | null>(null);
  const [restoredPurchases, setRestoredPurchases] = useState<
    UserPurchaseBalance[] | null
  >(null);
  const [username, setUsername] = useState<string | null>(null);

  // Currently unused while the payment flow is disabled (see initialize()).
  // Kept so it's a one-line change to wire back in when payments return.
  const fetchProducts = async (sdkInstance: SDKLiteInstance): Promise<void> => {
    try {
      const { products } = await sdkInstance.state.products();
      setProducts(products);
    } catch (e) {
      console.error("Failed to load products:", e);
      setProducts([]);
    }
  };

  // Callback for incomplete payments
  const onIncompletePaymentFound = (payment: any) => {
    console.log("[v0] Incomplete payment found:", payment);
    // Handle incomplete payment - could redirect to payment flow or show notification
    // For now, just log it
  };

  const initialize = async () => {
    console.log("[v0] Initialize called");
    setHasError(false);
    setRestoredPurchases(null);
    try {
      setAuthMessage("Loading Pi SDK...");
      console.log("[v0] Loading Pi SDK...");
      await loadPiSDK();
      setAuthMessage("Initializing Pi Network...");
      console.log("[v0] Initializing Pi Network");
      await window.Pi.init({
        version: "2.0",
        sandbox: PI_NETWORK_CONFIG.SANDBOX,
      });

      setAuthMessage("Authenticating with Pi...");
      console.log("[v0] Starting Pi.authenticate()");
      
      // Use Pi.authenticate() with the "username" scope only.
      // Payment flow (SDKLite, "payments" scope, products, purchase restore)
      // is TEMPORARILY DISABLED below while converting this app to a plain
      // Pi Sign-In flow for Pi App Studio. To re-enable payments later,
      // add "payments" back here and restore the SDKLite block that used
      // to follow the backend verification step (git history has it).
      const scopes = ["username"];
      const authResponse = await window.Pi.authenticate(scopes, onIncompletePaymentFound);
      
      console.log("[v0] Authentication successful, response:", authResponse);
      
      if (!authResponse || !authResponse.user || !authResponse.accessToken) {
        throw new Error("Authentication failed - no user data");
      }

      // Do NOT trust the client-reported user yet. Send the accessToken to
      // our backend, which calls GET https://api.minepi.com/v2/me with it
      // and only responds success once Pi confirms the token is valid.
      // The session (isAuthenticated/username) is only established after
      // that server-side check passes.
      setAuthMessage("Verifying with server...");
      console.log("[v0] Verifying access token with backend");
      const verifyRes = await fetch("/api/pi-user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: authResponse.accessToken }),
      });

      if (!verifyRes.ok) {
        throw new Error("Server could not verify Pi access token");
      }

      const verifyData = await verifyRes.json();
      if (!verifyData.success || !verifyData.user?.username) {
        throw new Error("Server rejected Pi access token");
      }

      // Use the server-verified identity as the source of truth.
      const piUsername = verifyData.user.username;
      console.log("[v0] Backend verified user:", verifyData.user);
      setUsername(piUsername);
      localStorage.setItem('pi_username', piUsername);
      localStorage.setItem('uid', verifyData.user.uid);
      localStorage.setItem('accessToken', authResponse.accessToken);

      // Payment flow disabled for now: no SDKLite load/init, no product
      // fetch, no purchase restore. sdk/products/restoredPurchases stay at
      // their initial null values so pages that read them (buy-now-button,
      // checkout, etc.) fall back to empty state instead of crashing.
      console.log("[v0] Login-only flow complete (payments disabled)");
      setIsAuthenticated(true);
    } catch (err) {
      console.error("[v0] Pi authentication failed:", err);
      setHasError(true);
      setAuthMessage(
        err instanceof Error
          ? err.message
          : "Authentication failed. Please try again.",
      );
    }
  };

  useEffect(() => {
    // Try to restore username from localStorage
    const savedUsername = localStorage.getItem('pi_username');
    if (savedUsername) {
      setUsername(savedUsername);
    }
    initialize();
  }, []);

  const value: PiAuthContextType = {
    isAuthenticated,
    authMessage,
    hasError,
    sdk,
    products,
    restoredPurchases,
    username,
    reinitialize: initialize,
  };

  return (
    <PiAuthContext.Provider value={value}>{children}</PiAuthContext.Provider>
  );
}

export function usePiAuth() {
  const context = useContext(PiAuthContext);
  if (context === undefined) {
    throw new Error("usePiAuth must be used within a PiAuthProvider");
  }
  return context;
}
